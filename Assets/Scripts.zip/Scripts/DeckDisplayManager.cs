using UnityEngine;
using System.Collections.Generic;

public class DeckDisplayManager : MonoBehaviour
{
    // Le panel dans lequel seront affich�es les cartes dans FirstMapScene
    public Transform unitCardPanel;

    // Le prefab de carte (il peut s'agir du m�me que celui utilis� dans le DeckUIManager, ou d'une version adapt�e pour l'affichage en jeu)
    public GameObject cardPrefab;

    private void Start()
    {
        // V�rifier que le DeckUIManager existe et que le deck est disponible
        if (DeckUIManager.Instance == null)
        {
            Debug.LogError("DeckUIManager non trouv� ! Assurez-vous qu'il est persistant ou que les donn�es du deck sont correctement stock�es.");
            return;
        }

        List<UnitData> deck = DeckUIManager.Instance.selectedDeckCards;
        Debug.Log("[DeckDisplayManager] Affichage du deck contenant " + deck.Count + " cartes.");

        // Vider le panel d'affichage (au cas o� il y aurait d�j� des enfants)
        foreach (Transform child in unitCardPanel)
        {
            Destroy(child.gameObject);
        }

        // Pour chaque carte dans le deck, instancier une visualisation dans le panel
        foreach (UnitData data in deck)
        {
            GameObject cardObj = Instantiate(cardPrefab, unitCardPanel);
            UnitCardUI cardUI = cardObj.GetComponent<UnitCardUI>();
            if (cardUI != null)
            {
                cardUI.Initialize(data);
            }
            else
            {
                Debug.LogWarning("Le prefab de carte n'a pas de composant UnitCardUI attach�.");
            }
        }
    }
}

