using System.Collections.Generic;
using UnityEngine;

public class CamouflageManager : MonoBehaviour
{
    public GridManager gridManager;   // R�f�rence au gestionnaire de grille
    public TurnManager turnManager;   // R�f�rence au gestionnaire de tours

    // Pour un syst�me de fog of war (vision)
    public int defaultVisionRange = 3;

    void Start()
    {
        if (gridManager == null)
            gridManager = FindObjectOfType<GridManager>();
        if (turnManager == null)
            turnManager = FindObjectOfType<TurnManager>();
    }

    void Update()
    {
        // V�rifie que nos r�f�rences sont d�finies
        if (turnManager == null || gridManager == null)
            return;

        Team currentTeam = turnManager.currentTeam;
        UnitController[] allUnits = FindObjectsOfType<UnitController>();

        foreach (UnitController unit in allUnits)
        {
            // On r�cup�re le SpriteRenderer
            SpriteRenderer sr = unit.GetComponent<SpriteRenderer>();
            if (sr == null)
                continue;

            // On r�cup�re le canvas des points de vie (assum� �tre un enfant de l'unit�)
            Canvas lifePointCanvas = unit.GetComponentInChildren<Canvas>();

            // Les unit�s de la team en cours sont toujours visibles
            if (unit.team == currentTeam)
            {
                if (!sr.enabled)
                {
                    sr.enabled = true;
                    Debug.Log("Unit " + unit.name + " (team " + unit.team + ") est alli�e et visible.");
                }
                if (lifePointCanvas != null && !lifePointCanvas.gameObject.activeSelf)
                {
                    lifePointCanvas.gameObject.SetActive(true);
                }
                continue;
            }

            // Pour une unit� adverse, v�rifier le camouflage
            bool camo = IsUnitCamouflaged(unit, currentTeam);
            sr.enabled = !camo;
            if (lifePointCanvas != null)
            {
                lifePointCanvas.gameObject.SetActive(!camo);
            }
            Debug.Log("Unit " + unit.name + " (team " + unit.team + ") camouflage=" + camo);
        }

        // Vous pouvez aussi appeler ici UpdateFogOfWar() pour un syst�me de fog of war complet.
    }


    /// <summary>
    /// Retourne true si l'unit� est camoufl�e pour un observateur appartenant � observerTeam.
    /// Conditions :
    /// - L'unit� adverse doit se trouver sur une for�t.
    /// - Aucune unit� de observerTeam ne doit se trouver sur une cellule adjacente.
    /// Les unit�s alli�es sont toujours visibles.
    /// </summary>
    public bool IsUnitCamouflaged(UnitController unit, Team observerTeam)
    {
        // Si l'unit� appartient � l'�quipe observatrice, elle est visible.
        if (unit.team == observerTeam)
        {
            Debug.Log("IsUnitCamouflaged: " + unit.name + " est alli�e => visible");
            return false;
        }

        // R�cup�rer la cellule sur laquelle se trouve l'unit�.
        GridCell cell = gridManager.GetCell(unit.position);
        if (cell == null)
        {
            Debug.Log("IsUnitCamouflaged: " + unit.name + " n'a pas de cell => visible");
            return false;
        }

        // L'unit� n'est camoufl�e que si elle est sur une for�t.
        if (cell.terrain != TerrainType.Forest)
        {
            Debug.Log("IsUnitCamouflaged: " + unit.name + " terrain=" + cell.terrain + " (non Forest) => visible");
            return false;
        }

        // V�rifier si une unit� de observerTeam se trouve sur une cellule adjacente.
        List<GridCell> neighbors = gridManager.GetNeighbors(unit.position);
        foreach (GridCell neighbor in neighbors)
        {
            UnitController adjacentUnit = gridManager.GetUnitAtPosition(neighbor.position);
            if (adjacentUnit != null && adjacentUnit.team == observerTeam)
            {
                Debug.Log("IsUnitCamouflaged: " + unit.name + " a " + adjacentUnit.name + " adjacent de team " + observerTeam + " => visible");
                return false;
            }
        }

        Debug.Log("IsUnitCamouflaged: " + unit.name + " est camoufl�e pour l'observateur de team " + observerTeam);
        return true;
    }

    /// <summary>
    /// Calcule l'ensemble des cellules visibles pour une �quipe donn�e en combinant
    /// le champ de vision de toutes ses unit�s. (Pour un syst�me de fog of war de base)
    /// </summary>
    public List<Vector2Int> CalculateVisibleCells(Team team)
    {
        HashSet<Vector2Int> visibleCells = new HashSet<Vector2Int>();
        UnitController[] allUnits = FindObjectsOfType<UnitController>();
        foreach (UnitController unit in allUnits)
        {
            if (unit.team == team)
            {
                int visionRange = defaultVisionRange;
                Vector2Int center = unit.position;
                for (int dx = -visionRange; dx <= visionRange; dx++)
                {
                    for (int dy = -visionRange; dy <= visionRange; dy++)
                    {
                        if (dx * dx + dy * dy <= visionRange * visionRange)
                        {
                            Vector2Int pos = new Vector2Int(center.x + dx, center.y + dy);
                            visibleCells.Add(pos);
                        }
                    }
                }
            }
        }
        return new List<Vector2Int>(visibleCells);
    }

    /// <summary>
    /// Exemple de m�thode pour mettre � jour le fog of war.
    /// Cette m�thode pourrait, par exemple, assombrir les cellules non visibles.
    /// L'impl�mentation d�pend de votre syst�me d'affichage.
    /// </summary>
    public void UpdateFogOfWar()
    {
        List<Vector2Int> visibleCells = CalculateVisibleCells(turnManager.currentTeam);
        // Impl�mentez ici la mise � jour du rendu du fog of war.
    }
}
