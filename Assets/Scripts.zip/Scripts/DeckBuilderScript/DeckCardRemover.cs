using UnityEngine;
using UnityEngine.EventSystems;

public class DeckCardRemover : MonoBehaviour, IPointerClickHandler
{
    public void OnPointerClick(PointerEventData eventData)
    {
        Debug.Log("[DeckCardRemover] Carte cliqu�e pour suppression : " + gameObject.name);
        // R�cup�rer la donn�e de l'unit� via le composant UnitCardUI
        UnitCardUI cardUI = GetComponent<UnitCardUI>();
        if (cardUI != null)
        {
            // Mise � jour du deck en retirant la carte (UnitData associ�e)
            DeckUIManager.Instance.RemoveCardFromDeck(cardUI.unitData);
        }
        // D�truire l'instance affich�e dans le DeckPanel
        Destroy(gameObject);
    }
}
