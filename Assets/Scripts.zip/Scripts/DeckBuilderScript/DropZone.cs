using UnityEngine;
using UnityEngine.EventSystems;

public class DropZone : MonoBehaviour, IDropHandler
{
    public void OnDrop(PointerEventData eventData)
    {
        Debug.Log("[DropZone] OnDrop appel� sur " + gameObject.name);
        if (eventData.pointerDrag != null)
        {
            // Rattacher l'objet � cette zone (le DeckPanel)
            eventData.pointerDrag.transform.SetParent(transform, false);

            // R�cup�rer le composant UnitCardUI pour obtenir la donn�e UnitData
            UnitCardUI unitCard = eventData.pointerDrag.GetComponent<UnitCardUI>();
            if (unitCard != null)
            {
                // Utiliser le singleton de DeckUIManager pour ajouter la carte au deck
                DeckUIManager.Instance.AddCardToDeck(unitCard.unitData);
                Debug.Log("[DropZone] Carte ajout�e au deck : " + unitCard.unitData.unitName);
            }
            else
            {
                Debug.LogWarning("[DropZone] Le composant UnitCardUI est introuvable sur l'objet draggu�.");
            }
        }
    }
}



