using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections;

public class UnitCardUI : MonoBehaviour
{
    [Header("References to UI Elements")]
    public Image cardBackground;      // Image d'arri�re-plan du panneau de la carte
    public Image unitSpriteImage;     // Image pour afficher le sprite de l'unit� (g�n�ralement sur un enfant)
    public TextMeshProUGUI biomassText; // Texte pour la biomasse

    [Header("Unit Data")]
    public UnitData unitData;         // Donn�es de l'unit�
    public GameObject unitPrefab;     // Prefab de l'unit� (pour deployment)

    // R�f�rences internes
    private RectTransform rectTransform;
    private CanvasGroup canvasGroup;
    private Canvas canvas;

    private void Awake()
    {
        // R�cup�ration des composants attach�s � cet objet.
        rectTransform = GetComponent<RectTransform>();
        canvasGroup = GetComponent<CanvasGroup>();
        if (canvasGroup == null)
        {
            // S'il n'existe pas, on l'ajoute pour la gestion de l'alpha si n�cessaire.
            canvasGroup = gameObject.AddComponent<CanvasGroup>();
        }
        canvas = GetComponentInParent<Canvas>();

        // Forcer l'activation du GameObject parent (celui-ci) si besoin
        if (!gameObject.activeSelf)
            gameObject.SetActive(true);

        // Forcer l'activation du composant Image du parent (celui qui est sur le GameObject racine)
        // On utilise GetComponent<Image>() ici pour r�cup�rer le composant Image attach� directement au prefab.
        Image parentImage = GetComponent<Image>();
        if (parentImage != null)
        {
            if (!parentImage.gameObject.activeSelf)
                parentImage.gameObject.SetActive(true);
            parentImage.enabled = true;
        }

        // Forcer l'activation des autres composants UI d�finis dans l'inspecteur.
        if (cardBackground != null)
        {
            if (!cardBackground.gameObject.activeSelf)
                cardBackground.gameObject.SetActive(true);
            cardBackground.enabled = true;
        }
        if (unitSpriteImage != null)
        {
            if (!unitSpriteImage.gameObject.activeSelf)
                unitSpriteImage.gameObject.SetActive(true);
            unitSpriteImage.enabled = true;
        }
        if (biomassText != null)
        {
            if (!biomassText.gameObject.activeSelf)
                biomassText.gameObject.SetActive(true);
            biomassText.enabled = true;
        }
        Debug.Log("[UnitCardUI] Awake called sur " + gameObject.name +
          " avec Image = " + (GetComponent<Image>() != null) +
          " et CanvasGroup = " + (GetComponent<CanvasGroup>() != null));
    }

    private void Start()
    {
        // Optionnel : on lance une coroutine pour v�rifier que tous les composants restent activ�s apr�s
        StartCoroutine(ForceActivationAfterFrame());
    }

    private IEnumerator ForceActivationAfterFrame()
    {
        // Attendre la fin de la frame pour v�rifier l'�tat
        yield return null;

        // Forcer � nouveau l'activation (au cas o� quelque chose d�sactiverait les composants apr�s Awake())
        Image parentImage = GetComponent<Image>();
        if (parentImage != null)
        {
            if (!parentImage.gameObject.activeSelf)
                parentImage.gameObject.SetActive(true);
            parentImage.enabled = true;
            Debug.Log($"[ForceActivationAfterFrame] Parent Image activ� sur {gameObject.name}");
        }

        if (cardBackground != null)
        {
            if (!cardBackground.gameObject.activeSelf)
                cardBackground.gameObject.SetActive(true);
            cardBackground.enabled = true;
            Debug.Log($"[ForceActivationAfterFrame] CardBackground activ� sur {gameObject.name}");
        }
        if (unitSpriteImage != null)
        {
            if (!unitSpriteImage.gameObject.activeSelf)
                unitSpriteImage.gameObject.SetActive(true);
            unitSpriteImage.enabled = true;
            Debug.Log($"[ForceActivationAfterFrame] UnitSpriteImage activ� sur {gameObject.name}");
        }
        if (biomassText != null)
        {
            if (!biomassText.gameObject.activeSelf)
                biomassText.gameObject.SetActive(true);
            biomassText.enabled = true;
            Debug.Log($"[ForceActivationAfterFrame] BiomassText activ� sur {gameObject.name}");
        }
    }

    // Cette m�thode sert uniquement � initialiser l'affichage de la carte.
    public void Initialize(UnitData data)
    {
        Debug.Log($"[UnitCardUI::Initialize] Pour '{gameObject.name}' avec unitData = '{(data != null ? data.unitName : "NULL")}'");

        unitData = data;
        unitPrefab = data.unitPrefab;

        if (unitSpriteImage != null)
        {
            if (data.unitSprite != null)
            {
                unitSpriteImage.sprite = data.unitSprite;
                Debug.Log($"[UnitCardUI::Initialize] Sprite '{data.unitSprite.name}' assign� � '{gameObject.name}', colorAlpha={unitSpriteImage.color.a}");
            }
            else
            {
                Debug.LogWarning($"[UnitCardUI::Initialize] data.unitSprite est null pour {data.unitName} !");
            }
        }
        else
        {
            Debug.LogWarning($"[UnitCardUI::Initialize] unitSpriteImage n'est pas assign� sur '{gameObject.name}'");
        }

        if (biomassText != null)
        {
            biomassText.text = data.biomass.ToString();
        }
    }
}








